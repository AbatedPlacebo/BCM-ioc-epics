Title:   readme

[TOP](index)

{{TOC}}

Заготовка genlib IOC

# Получение


```sh
ln -s <path_to_genlib_example>/makeIOCfromGenlibTemplate.sh ~/bin
```

```sh
makeIOCfromGenlibTemplate.sh -h
makeIOCfromGenlibTemplate.sh -app appname
```

