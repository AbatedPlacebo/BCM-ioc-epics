#ifndef _TEMPLATE__H
#define _TEMPLATE__H

#define VAR_MBB_V0 0
#define VAR_MBB_V1 1
#define VAR_MBB_V2 2
#define VAR_MBB_V3 3

#define MBB_FIELD_mbb \
  MBB_FIELD_N(VAR_MBB_,V0) \
  MBB_FIELD_N(VAR_MBB_,V1) \
  MBB_FIELD_N(VAR_MBB_,V2) \
  MBB_FIELD_N(VAR_MBB_,V3)

#define MBB_FIELD_mbb_ro MBB_FIELD_mbb

/* PLACE_MBB_INSERT */

#define DECL__TEMPLATE_(decl_zone) \
  decl_zone##_VAR(int,var,0,1000000000,DATA_EVENT,3) \
  decl_zone##_VAR_RO(int,var_ro,0,1000000000,DATA_EVENT) \
  decl_zone##_BIN(bin,DATA_EVENT,0) \
  decl_zone##_BIN_RO(bin_ro,DATA_EVENT) \
  decl_zone##_MBB(mbb,VAR_MBB_V0,VAR_MBB_V3,DATA_EVENT,VAR_MBB_V1) \
  decl_zone##_MBB_RO(mbb_ro,VAR_MBB_V0,VAR_MBB_V3,DATA_EVENT) \
  decl_zone##_ARR(int,arr,10,0,1000000000,DATA_EVENT,{0}) \
  decl_zone##_ARR_RO(int,arr_ro,10,0,1000000000,DATA_EVENT) \
/* PLACE_VAR_INSERT */

#include "gen_h.h"

struct T_TEMPLATE_{
  DECL__TEMPLATE_(STRUCT);
};
typedef struct T_TEMPLATE_ T_TEMPLATE_;

#endif
